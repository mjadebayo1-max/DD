export const NETWORK_ID = 31337 as number;
export const NETWORK_NAME = 'localhost' as string;
