import { atom } from 'jotai';

export const destinationAddressAtom = atom<string>('');
